# Meet‑Vendors — Static Tailwind Preview

Open `index.html` and click around. Uses Tailwind CDN for styling.

Pages:
- index.html
- vendors.html
- vendor-profile.html
- join.html
- pricing.html
- dashboard-vendor.html
- dashboard-company.html
- admin.html

© 2025 Meet‑Vendors — static preview only.
